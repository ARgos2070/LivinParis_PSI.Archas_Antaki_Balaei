using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PSI_application_C__web.Pages
{
    public class Page_choix_particulier_ou_entrepriseModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
