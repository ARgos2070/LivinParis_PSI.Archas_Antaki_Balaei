using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PSI_application_C__web.Pages
{
    public class Ajout_platModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
